package com.example.hotelreservation.exception;

public enum ReservationErrorType {
    ROOM_NOT_FOUND,
    DATE_CONFLICT
}
