package com.example.hotelreservation.model;

public enum ReservationStatus {
    RESERVED,
    CANCELED
}