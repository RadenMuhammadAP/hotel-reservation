package com.example.hotelreservation.model;

public enum Availability {
    AVAILABLE,
    BOOKED
}